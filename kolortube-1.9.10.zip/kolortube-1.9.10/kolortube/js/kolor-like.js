(function($){
  $(document).ready(function(){
    $(document).on('click', '.kolor-like-btn, a[data-post_id][data-post_like]', function(e){
      e.preventDefault();
      var $btn = $(this);
      if ( $btn.data('kolor-disabled') ) return;
      var post_id = $btn.data('postId') || $btn.data('post_id') || $btn.attr('data-post_id');
      var post_like = $btn.data('postLike') || $btn.data('post_like') || 'like';
      if (!post_id) return;
      $btn.data('kolor-disabled', true).addClass('is-loading');

      // Use localized wpst_ajax_var provided by the theme (url + nonce)
      $.post( wpst_ajax_var.url, {
        action: 'post-like',
        post_id: post_id,
        post_like: post_like,
        nonce: wpst_ajax_var.nonce
      }).done(function(response){
        // response structure comes from ajax/post-like.php
        if ( response && typeof response.likes !== 'undefined' ) {
          $btn.closest('.post-like').find('.likes_count').text(response.likes);
        }
        if ( response && typeof response.dislikes !== 'undefined' ) {
          $btn.closest('.post-like').find('.dislikes_count').text(response.dislikes);
        }
        // Add an active state to the clicked button
        $btn.addClass('is-active');

        // Optionally, update percentage/progressbar if present
        if ( response && typeof response.percentage !== 'undefined' ) {
          $btn.closest('.post-like').find('.rating-bar-meter').css('width', response.percentage + '%');
        }
      }).fail(function(){
        // silent fail for now
      }).always(function(){
        $btn.data('kolor-disabled', false).removeClass('is-loading');
      });
    });
  });
})(jQuery);
