# KolorTube 1.9.10 — Release notes

This file is a release summary for KolorTube 1.9.10 (branch: fix/kolortube-1.9.10).

Summary of fixes included in this build

- Fix: Make Like button work (AJAX)
  - Added a small, self-contained frontend handler: `js/kolor-like.js` — sends AJAX POST to existing endpoint `ajax/post-like.php` (action `post-like`) using the theme-localized `wpst_ajax_var` (url + nonce).
  - The handler updates likes/dislikes counts and progress bar UI immediately after a successful request.
  - No new server-side endpoints were added; the existing `ajax/post-like.php` is used.

- Fix: Prevent horizontal overflow on devices with vertical scrollbars (iPad, iPad Pro, desktop with visible scrollbar)
  - Added CSS overrides to avoid `100vw` pitfalls and use `calc(-50vw + 50%)` centering technique for full-bleed player.
  - File modified: `css/custom.css` (overrides appended at the end of the file).

- Style: Pink color overrides for category/tag/actor/studio badges and capsule buttons
  - Added safe CSS overrides at the end of `css/custom.css` so existing theme styles remain intact. Provides pink gradient and hover/active states as requested.

Files changed (on branch `fix/kolortube-1.9.10`)

- Added: `js/kolor-like.js`
- Modified: `inc/enqueue.php` — enqueue the new script
- Modified: `css/custom.css` — appended overrides for 100vw fix and pink color scheme

Branch & download

- Branch (source): https://github.com/Bosszer44/kolortube/tree/fix%2Fkolortube-1.9.10
- Commit: https://github.com/Bosszer44/kolortube/commit/9a40f0d170a25cb590a0b4c73b7bfecc73451229
- Auto-generated ZIP (branch archive) you can download now: https://github.com/Bosszer44/kolortube/archive/refs/heads/fix/kolortube-1.9.10.zip

Notes about installation/testing

1. Install the theme from the ZIP on a staging site: Appearance → Themes → Add → Upload theme → choose the ZIP.
2. Clear any caching plugins and browser cache.
3. Visit a single-video page and click the Like button:
   - Confirm an AJAX POST to `admin-ajax.php` (action `post-like`) — use browser devtools Network tab.
   - The likes/dislikes numbers and progress bar should update without a page reload.
4. Test on iPad / responsive emulation to ensure horizontal scrollbar is gone and layout is stable.

If you want me to create an official GitHub Release (tag `v1.9.10` and a Release entry with this changelog and the ZIP attached), I can prepare the release body and the tag text for you to paste into the GitHub Releases UI and upload the ZIP. At the moment I cannot create the GitHub Release programmatically from this session, so please let me know if you want me to:

- (A) Prepare the exact Release title + body (I will paste it here and you can create the Release on GitHub), or
- (B) Guide you with step-by-step clicks to create the Release and attach the ZIP, or
- (C) If you prefer, I can commit the compiled ZIP into the repository as `KolorTube-1.9.10.zip` (note: repository will grow in size).

Thank you — tell me which option you prefer for creating the Release (A, B or C) or if you want me to proceed with the release text now.
