<?php
/** Silence is golden. */
