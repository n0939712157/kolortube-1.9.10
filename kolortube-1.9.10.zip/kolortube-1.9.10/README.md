# KolorTube Theme

ธีม WordPress KolorTube ที่ปรับแต่งสำหรับการติดตั้งจริง โดยใช้โฟลเดอร์ธีม
`kolortube` และคงชื่อธีม/Theme Mods เดิมเพื่อให้อัปเดตทับธีมเดิมได้

## สถานะล่าสุด

- โครงสร้าง source อยู่ใน [`kolortube/`](./kolortube/)
- มี source ทั้งหมด 286 ไฟล์จากแพ็กเกจธีม
- ตรวจ PHP 203 ไฟล์ด้วย `php -l` แล้ว ไม่พบ syntax error
- framework หลักโหลดผ่าน WordPress ได้สำเร็จ
- ใช้โฟลเดอร์ slug เดิม `kolortube` ไม่สร้างธีมซ้ำ
- มีแพ็กเกจติดตั้งพร้อมใช้ [`kolortube_1.zip`](./kolortube_1.zip)
- ระบบติดตั้ง ZIP จะจับคู่กับธีมหลักที่เปิดใช้งานอยู่ แม้ชื่อไฟล์หรือโฟลเดอร์ใน ZIP จะแตกต่างกัน

## การติดตั้ง

1. สำรองธีมเดิมและฐานข้อมูลก่อนอัปเดต
2. ดาวน์โหลด [`kolortube_1.zip`](./kolortube_1.zip)
3. ไปที่ **Appearance > Themes > Add New > Upload Theme** ใน WordPress
4. เลือก ZIP แล้วกดติดตั้ง/อัปเดต ระบบจะอัปเดตทับธีมหลักที่เปิดใช้งานเพียงตัวเดียว
5. หากใช้วิธีคัดลอกไฟล์เอง ให้นำโฟลเดอร์ `kolortube` ไปไว้ที่ `wp-content/themes/kolortube/`
6. ล้าง cache/CDN และตรวจหน้าแรก หน้าวิดีโอ หมวดหมู่ Studio และ Actors

> การอัปเดตไฟล์ไม่ลบค่า `theme_mods` หรือค่าที่บันทึกในฐานข้อมูล

> **หมายเหตุ:** ZIP ต้องมี `style.css` อยู่ที่ `kolortube/style.css` ภายในแพ็กเกจ
> และระบบจะไม่สร้างธีมใหม่จากชื่อโฟลเดอร์ ZIP ที่แตกต่างกัน

## โครงสร้างไฟล์และหน้าที่

### ไฟล์ระดับธีม

- `functions.php` — bootstrap, helper รูปภาพ, contrast, Histats bridge, fallback โฆษณา และโหลด `WPS_Framework`
- `header.php`, `footer.php`, `sidebar.php` — โครง HTML หลักของเว็บไซต์
- `index.php`, `archive.php`, `search.php`, `single.php`, `page.php` — template การแสดงผลหลัก
- `category.php`, `tag.php`, `taxonomy-actors.php`, `taxonomy-studio.php` — archive ของ taxonomy
- `template-*.php`, `page-templates/` — หน้าและ layout เฉพาะทาง
- `loop-templates/`, `global-templates/`, `sidebar-templates/` — partials ที่ใช้ซ้ำในหน้าเว็บ
- `style.css` — theme header ของ WordPress

### `inc/` ระบบหลัก

- `class-wps-framework.php` — singleton bootstrap, โหลด modules ตามลำดับ dependency, โหลด legacy files และแสดง load errors ใน admin
- `customizer.php`, `customizer/` — ลงทะเบียน Customizer controls, sanitizers, settings และ frontend output
- `customizer/color-registry.php` — source of truth ของสีทั้งหมด
- `customizer/class-wps-customizer-colors.php` — controls สีและค่า default
- `customizer/customizer-output.php` — แปลงค่าจาก Customizer เป็น CSS variables และ inline CSS
- `enqueue.php` — enqueue CSS/JS, nonce และ AJAX configuration
- `setup.php`, `init.php`, `hooks.php`, `extras.php` — WordPress hooks, theme supports และ compatibility
- `template-tags.php`, `pagination.php`, `social-icons.php` — helper สำหรับ template
- `video-functions.php`, `post-like.php`, `actor-image.php`, `actors.php`, `studio.php` — วิดีโอ, like/view และ taxonomy media
- `widgets.php`, `widget-video-filters.php`, `widget-video-cats.php`, `widget-video-tags.php` — widgets และตัวกรอง
- `final/` — finalizer, default settings, taxonomy cleanup และ frontend hardening
- `professional/` — home sections, banner settings และ professional frontend/admin UI
- `ads/` — ad slots และ rendering
- `seo/`, `search/` — SEO metadata, breadcrumbs, taxonomy robots และ search index
- `security/`, `cache/`, `performance/`, `redirect/` — security headers, cache, performance และ redirects
- `images/`, `media/`, `video/` — WebP, media backup และ metadata
- `system/` — installer, task runner/store, health check, rule engine, self-healing และ status
- `control-center-42/` — admin control center, labels, file/media matching และ selective transfer
- `control-center-42/class-wps-file-manager.php` — Super File Manager สำหรับแก้ไข/อัปโหลดไฟล์ สำรองก่อนแก้ไข และดาวน์โหลดโฟลเดอร์เป็น ZIP
- การดาวน์โหลด ZIP ใช้ `ZipArchive` เมื่อมีใน PHP และใช้ PclZip ของ WordPress เป็น fallback เมื่อไม่มี extension นี้
- `integrations/` — Google Drive และ secrets integration
- `helpers/`, `database/`, `tools/`, `backup/`, `dashboard/`, `analytics/` — utility และระบบสนับสนุน

### `ajax/`, `admin/`, `tgmpa/`, `vendor/`

- `ajax/` — endpoint สำหรับ async post data, preview, like และ views
- `admin/` — metabox, admin options, dashboard และ admin assets
- `tgmpa/` — ตัวช่วยแนะนำ/ติดตั้งปลั๊กอิน
- `vendor/` — Composer autoloader และ dependencies ที่ธีมใช้

### Frontend assets

- `css/theme.min.css` — base theme CSS
- `css/custom.css` — custom responsive/color bridge และ final overrides
- `css/gallery-lightbox.css` — gallery/lightbox styling
- `js/theme.min.js`, `js/main.js` — interaction และ frontend behavior
- `js/gallery-lightbox.js` — gallery lightbox
- `js/customizer.js`, `js/customizer-panel.js` — live preview และ Customizer controls
- `js/slick/` — slider library
- `assets/` — admin/professional/live analytics assets
- `img/`, `fonts/` — images, fallback thumbnails และ icon fonts

## ระบบสีและ Customizer

ลำดับการทำงานคือ:

1. `color-registry.php` กำหนด key, default, group และความสัมพันธ์กับ Main Color
2. `class-wps-customizer-colors.php` ลงทะเบียน setting/control และ sanitizer
3. ผู้ใช้บันทึกค่าเป็น WordPress `theme_mod`
4. `customizer-output.php` อ่านค่าจริงจาก registry
5. CSS variables ถูกพิมพ์ลง frontend และใช้โดย `custom.css`

สีหลัก ได้แก่ background, menu/header, dropdown, buttons, links, labels, cards,
taxonomy capsules, player, footer, forms และข้อความ พร้อม fallback ที่ปลอดภัย
และการเลือกสีข้อความตาม contrast

## การแก้ไขล่าสุด

- กู้คืน framework ที่หาย: `inc/class-wps-framework.php`
- กู้คืน modules และ legacy files ที่ขาด เพื่อแก้ Fatal error จาก `require_once`
- เพิ่ม/คืน Customizer controls, color registry, output และ default installer
- เชื่อมค่าจาก Customizer ไปยัง CSS variables และ frontend จริง
- เพิ่ม fallback ของ Ads เมื่อ module ภายนอกไม่พร้อม
- เชื่อม `In player ad zone 1/2` จาก Customizer ไปยัง markup จริงเหนือ player พร้อมปุ่มปิด
- ให้ระบบ Ads อ่านค่าจาก Customizer ได้แม้ inventory กลางยังไม่มี slot ที่ migrate แล้ว
- แก้ default installer รุ่น 1.1.2 ไม่ให้ซ่อนปุ่มถูกใจ และ migrate ค่าผิดพลาดจากรุ่น 1.1.1
- ตรวจเส้นทางปุ่มถูกใจตั้งแต่ template → `main.js` → AJAX action `post-like`
- แก้ footer ให้โปร่งใสด้วย:

```css
html body #wrapper-footer,
html body #wrapper-footer .site-footer,
html body #wrapper-footer .site-footer .site-info {
    background: transparent !important;
}
```

- คง slug `kolortube` เพื่ออัปเดตทับธีมเดิมโดยไม่เกิดธีมซ้ำ
- ตรวจ PHP syntax ครบ 203 ไฟล์ และ smoke-test การโหลด WordPress แล้ว

## การตรวจสอบก่อน release

```powershell
Get-ChildItem .\kolortube -Recurse -File -Filter *.php |
  ForEach-Object { php -l $_.FullName }
```

ตรวจให้แน่ใจว่าไฟล์สำคัญต่อไปนี้ยังอยู่:

- `kolortube/style.css`
- `kolortube/functions.php`
- `kolortube/inc/class-wps-framework.php`
- `kolortube/inc/customizer.php`
- `kolortube/inc/customizer/color-registry.php`
- `kolortube/inc/customizer/customizer-output.php`
- `kolortube/css/custom.css`
- `kolortube/js/main.js`

## ข้อควรระวัง

- อย่า commit `wp-config.php`, credentials, API keys หรือไฟล์ secret
- อย่าลบ `theme_mods` ระหว่างอัปเดตธีม
- หลังอัปเดตให้ล้าง page cache, object cache และ CDN
- หาก module ภายนอกไม่ทำงาน ให้ตรวจหน้า health/status ใน WordPress admin
